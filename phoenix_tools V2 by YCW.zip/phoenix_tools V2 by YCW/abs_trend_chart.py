# -*- coding: UTF-8 -*-

from pyecharts import Line
import pandas as pd

CHART_NAMES = ["收盘点位", "均线", "绝对温度", "相对温度", "平均温度", "PB", "PE", "ROE", "V_PB", "10国债%"]
# Y_AXIS_NAMES = ['收盘价', '温度']
LINE_COLOR = ['#000000', '#800080', '#c23531', '#006400',  '#FFD306', '#FCFCFC', '#FCFCFC', '#FCFCFC', '#FCFCFC', '#FCFCFC']


def option_process(stockCode, stockName, names, x_axis, y_axises1, y_axises2, Y_AXIS_NAMES):
    option = {
        "title": {
            "text": stockName + '(' + stockCode + ')',
            "textAlign": 'center',
            'left': 200,
            'top': 10
            },

        "toolbox": {
            "orient": "vertical",
            'top': 60,
            "right": 50,
            "feature": {
                "dataZoom": {
                    "yAxisIndex": True
                },
                "brush": {
                    "type": ["lineX", "clear"]
                }
            }
        },
        "tooltip": {
            "trigger": "axis",
            # "axisPointer": {
            #     "type": "cross"
            #     }
        },
        "legend": {
            "data": names,
            'top': 10
        },
        "grid": {
            "left": "10%",
            "right": "10%",
            "bottom": "15%"
        },
        "xAxis": {
            "type": "category",
            "data": x_axis,
            "scale": True,
            "boundaryGap": False,
            "axisLine": {
                "onZero": False
            },
            "splitLine": {
                "show": False
            },
            "splitNumber": 40,
            "min": "dataMin",
            "max": "dataMax"
        },
        "yAxis": [
            {
                "name": Y_AXIS_NAMES[0],
                "type": "value",
                "min": "dataMin",
                "max": "dataMax",
                # "maxInterval": 1000,
                "minInterval": 100,
                "splitLine": {
                    "show": False
                },
                # "nameLocation": 'start',
                # "max": 5,
                # "type": 'value',
            },
            {
                "name": Y_AXIS_NAMES[1],
                "scale": True,
                "splitArea": {
                    "show": True
                },
                'max': 100,
                'interval': 10,
                'min': 0
                # 'boundaryGap': [0, '100%'],
            }
        ],
        "dataZoom": [{
            "type": "inside",
            "start": 90,
            "end": 100
        }, {
            "show": True,
            "type": "slider",
            "y": "90%",
            "start": 90,
            "end": 100
        }],
        'series': [],
        'legend': {
            'data': []
        }
    }
    for index, name in enumerate(names):
        line_width = 1
        if index == 0:
            yAxisIndex = 0
            data = y_axises1[0]
            #line_width = 3
        elif index == 1:
            yAxisIndex = 0
            data = y_axises1[1]
            #line_width = 3
        else:
            yAxisIndex = 1
            data = y_axises2[index - 2]

        if index > 4:
            line_width = 0
        show_temp = True
        series = {
            'type': 'line',
            'name': name,
            "yAxisIndex": yAxisIndex,
            'data': data,
            'symbol': 'none',
            "smooth": True,
            "lineStyle": {
                "width": line_width
            },
            "showSymbol ": False,
            "color": LINE_COLOR[index]
        }
        option['series'].append(series)

        if index < 5:
            option['legend']['data'].append(name)
    return option




def generate(df, flg, stockCode, stockName, is_gen_single):
    Y_AXIS_NAMES = ['收盘价', '温度']
    if flg is 'stock_A':
        Y_AXIS_NAMES = ['前复权', '温度']
    dates = df['date']
    y_axises2 = []
    y_axises2.append(df['absolute_temp'])
    y_axises2.append(df['relative_temp'])
    decimal = 3
    y_axises2.append(df['avg_temp'].round(decimals=decimal))
    y_axises2.append(df['pb'].round(decimals=decimal))
    y_axises2.append(df['pe'].round(decimals=decimal))
    y_axises2.append(df['roe'].round(decimals=decimal))
    y_axises2.append(df['s'].round(decimals=decimal))
    y_axises2.append(df['guozhai'].round(decimals=decimal))

    axis1 = df["cp"]
    axis2 = df["avg"]
    y_axises1 = []
    y_axises1.append(axis1)
    y_axises1.append(axis2)

    line = Line(width=1200, title=stockName)
    option = option_process(stockCode, stockName, CHART_NAMES, dates, y_axises1, y_axises2, Y_AXIS_NAMES)

    # line.render('output/temp_line.html')
    # line._option = getOption()
    file = 'output/abs_temp_line_' + flg + '_' + stockCode + '.html'
    line._option = option
    if is_gen_single is True:
        line.render(path=file, template_name='template/temp_history.html', object_name='line')
    return line


# generate()
